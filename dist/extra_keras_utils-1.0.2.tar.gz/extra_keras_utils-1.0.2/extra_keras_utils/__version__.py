"""Current version of package extra_keras_utils"""
__version__ = "1.0.2"